package org.example;

public class Person {
    private String firstName;
    private String secondName;
    private int age;
    private String gender;

    public Person() {}

    public Person(String firstName, String secondName, int age, String gender) {
        validate(firstName, secondName, age, gender);
        this.firstName = firstName;
        this.secondName = secondName;
        this.age = age;
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age <= 0 || age >= 150) {
            throw new IllegalArgumentException("Age must be greater than 0 and less than 150");
        }
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (!isValidGender(gender)) {
            throw new IllegalArgumentException("Invalid gender value");
        }
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (!isValidName(firstName)) {
            throw new IllegalArgumentException("First name must start with a letter and contain only letters");
        }
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        if (!isValidName(secondName)) {
            throw new IllegalArgumentException("Second name must start with a letter and contain only letters");
        }
        this.secondName = secondName;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", secondName='" + secondName + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                '}';
    }

    private void validate(String firstName, String secondName, int age, String gender) {
        if (firstName == null || firstName.isEmpty() || secondName == null || secondName.isEmpty() ||
                gender == null || gender.isEmpty()) {
            throw new IllegalArgumentException("All fields must be provided with valid values");
        }

        if (!isValidName(firstName) || !isValidName(secondName)) {
            throw new IllegalArgumentException("First name and second name must start with a letter");
        }

        if (age <= 0 || age >= 150) {
            throw new IllegalArgumentException("Age must be greater than 0 and less than 150");
        }

        if (!isValidGender(gender)) {
            throw new IllegalArgumentException("Invalid gender value");
        }
    }

    private boolean isValidName(String name) {
        return name.matches("^[a-zA-Z][a-zA-Z]*$");
    }

    private boolean isValidGender(String gender) {
        return gender.equals("Woman") || gender.equals("Man") ||
                gender.equals("Non-binary | gender diverse") ||
                gender.equals("Prefer not to say") || gender.equals("Other");
    }
}