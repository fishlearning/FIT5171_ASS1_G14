package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FlightCollection {

    public static ArrayList<Flight> flights = new ArrayList<>();

    public static ArrayList<Flight> getFlights() {
        return flights;
    }

    public static void addFlights(ArrayList<Flight> flights) {
        FlightCollection.flights.addAll(flights);
    }

    public static List<Flight> getFlightInfo(String city) {
        return flights.stream()
                .filter(f -> f.getDepartTo().equalsIgnoreCase(city))
                .collect(Collectors.toList());
    }

    public static List<Flight> getTwoFlightInfo(String city1, String city2) {
        return flights.stream()
                .filter(f -> f.getDepartTo().equalsIgnoreCase(city1) || f.getDepartTo().equalsIgnoreCase(city2))
                .collect(Collectors.toList());
    }

    public static Flight getFlightInfo(int flight_id) {
        return flights.stream()
                .filter(f -> f.getFlightID() == flight_id)
                .findFirst()
                .orElse(null);
    }
}