package org.example;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

public class AirplaneTest {

    @Test
    public void testSetAndGetAirplaneID() {
        Airplane airplane = new Airplane(2,"aa",1,2,3);
        airplane.setAirplaneID(2);
        assertEquals(2, airplane.getAirplaneID());
    }

    @Test
    public void testSetAndGetAirplaneModel() {
        Airplane airplane = new Airplane(1,"Airbus A380",1,2,3);
        airplane.setAirplaneModel("Airbus A380");
        assertEquals("Airbus A380", airplane.getAirplaneModel());
    }

    @Test
    public void testSetAndGetBusinessSitsNumber() {
        Airplane airplane = new Airplane(1,"Airbus A380",60,2,3);
        airplane.setBusinessSitsNumber(60);
        assertEquals(60, airplane.getBusinessSitsNumber());
    }

    @Test
    public void testSetAndGetEconomySitsNumber() {
        Airplane airplane = new Airplane(1,"Airbus A380",60,220,3);
        airplane.setEconomySitsNumber(220);
        assertEquals(220, airplane.getEconomySitsNumber());
    }

    @Test
    public void testSetAndGetCrewSitsNumber() {
        Airplane airplane = new Airplane(1,"Airbus A380",60,220,15);
        airplane.setCrewSitsNumber(15);
        assertEquals(15, airplane.getCrewSitsNumber());
    }

    @Test
    public void testBusinessSitsNumberRange() {
        Airplane airplane = new Airplane(1,"Airbus A380",0,220,15);
        assertThrows(IllegalArgumentException.class, () -> airplane.setBusinessSitsNumber(0));
        assertThrows(IllegalArgumentException.class, () -> airplane.setBusinessSitsNumber(301));
    }

    @Test
    public void testEconomySitsNumberRange() {
        Airplane airplane = new Airplane(1,"Airbus A380",60,20,15);
        assertThrows(IllegalArgumentException.class, () -> airplane.setEconomySitsNumber(0));
        assertThrows(IllegalArgumentException.class, () -> airplane.setEconomySitsNumber(301));
    }

    @Test
    public void testCrewSitsNumberRange() {
        Airplane airplane = new Airplane(1,"Airbus A380",60,220,15);
        assertThrows(IllegalArgumentException.class, () -> airplane.setCrewSitsNumber(0));
        assertThrows(IllegalArgumentException.class, () -> airplane.setCrewSitsNumber(301));
    }
}