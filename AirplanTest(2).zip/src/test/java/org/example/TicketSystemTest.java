package org.example;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.sql.Timestamp;
import java.util.Scanner;

import static org.example.Flight.parseTimestamp;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketSystemTest {
    @Mock
    Scanner scanner;

    private TicketSystem ticketSystem;
    TicketCollection ticketCollection;
    FlightCollection flightCollection;
    @BeforeEach
    void setUp() {
        ticketSystem = new TicketSystem();
        ticketCollection = new TicketCollection();
        flightCollection = new FlightCollection();

        Airplane airplane1 = new Airplane(1, "Boeing 737", 31, 61, 1);
        Flight flight1 = new Flight(1, "New York", "Los Angeles", "NY100", "Delta", parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1);
        Passenger passenger1 = new Passenger("John", "Doe", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Ticket ticket1 = new Ticket(1, 100, flight1,false,passenger1);

        Airplane airplane2 = new Airplane(2, "Boeing 737", 31, 61, 1);
        Flight flight2 = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane2);        Passenger passenger2 = new Passenger("John", "Doe", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Ticket ticket2 = new Ticket(2, 100, flight2, false, passenger2);

        Airplane airplane3 = new Airplane(3, "Boeing 737", 31, 61, 1);
        Flight flight3 = new Flight(3, "Suzhou", "Wuxi", "NY102", "BNA", parseTimestamp("03/07/24 10:00:00"), parseTimestamp("03/07/24 11:00:00"), airplane3);
        Passenger passenger3 = new Passenger("John", "Doe", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Ticket ticket3 = new Ticket(3, 100, flight3, false, passenger3);

        ticketCollection.tickets.add(ticket1);
        ticketCollection.tickets.add(ticket2);
        ticketCollection.tickets.add(ticket3);
        flightCollection.flights.add(flight1);
        flightCollection.flights.add(flight2);
        flightCollection.flights.add(flight3);
    }

    @Test
    void chooseAndBuyTicket_directFlight() throws Exception {
        when(scanner.next())
                .thenReturn("1")
                .thenReturn("John")
                .thenReturn("Doe")
                .thenReturn("25")
                .thenReturn("Man")
                .thenReturn("john.doe@example.com")
                .thenReturn("0412345678")
                .thenReturn("ABC123456")
                .thenReturn("1")
                .thenReturn("1234567")
                .thenReturn("123");

        ticketSystem.buyTicket.in = scanner;

        assertDoesNotThrow(() -> ticketSystem.chooseAndBuyTicket("city1", "city2"));

        verify(scanner, times(11)).next();
    }
}
