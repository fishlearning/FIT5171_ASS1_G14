package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class FlightTest {

    private Flight validFlight;
    private Airplane airplane;
    private Set<Flight> flightSet;

    //Set some information for using in test
    @BeforeEach
    public void setUp() {
        airplane = new Airplane(1,"AA",1,2,3); // Assuming Airplane has a default constructor
        validFlight = new Flight(
                1,
                "Nanjing",
                "Beijing",
                "NY100",
                "Delta",
                parseTimestamp("01/01/24 10:00:00"),
                parseTimestamp("01/01/24 14:00:00"),
                airplane
        );
        flightSet = new HashSet<>();
    }

    //set the format of date and time
    private Timestamp parseTimestamp(String dateStr) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            return new Timestamp(dateFormat.parse(dateStr).getTime());
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format", e);
        }
    }

    //test for the completeness of flight information
    @Test
    public void testAllFieldsRequired() {
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(0, "Nanjing", "Beijing", "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, null, "Beijing", "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", null, "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", null, "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", null, parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", "Delta", null, parseTimestamp("01/01/24 14:00:00"), airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), null, airplane));
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), null));
    }

    //test for date format
    @Test
    public void testInvalidDateFormat() {
        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", "Delta", parseTimestamp("01-01-24 10:00:00"), parseTimestamp("01/01/24 14:00:00"), airplane));

        assertThrows(IllegalArgumentException.class,
                () -> new Flight(1, "Nanjing", "Beijing", "NY100", "Delta", parseTimestamp("01/01/24 10:00:00"), parseTimestamp("01-01-24 14:00:00"), airplane));
    }

    //test for the process of flight adding
    @Test
    public void testValidFlightCreation() {
        assertNotNull(validFlight);
        assertEquals(1, validFlight.getFlightID());
        assertEquals("Nanjing", validFlight.getDepartTo());
        assertEquals("Beijing", validFlight.getDepartFrom());
        assertEquals("NY100", validFlight.getCode());
        assertEquals("Delta", validFlight.getCompany());
        assertEquals(parseTimestamp("01/01/24 10:00:00"), validFlight.getDateFrom());
        assertEquals(parseTimestamp("01/01/24 14:00:00"), validFlight.getDateTo());
        assertEquals(airplane, validFlight.getAirplane());
    }

    //test for adding duplicate flight
    @Test
    public void testDuplicateFlight() {
        flightSet.add(validFlight);
        Flight duplicateFlight = new Flight(
                1,
                "Nanjing",
                "Beijing",
                "NY100",
                "Delta",
                parseTimestamp("01/01/24 10:00:00"),
                parseTimestamp("01/01/24 14:00:00"),
                airplane
        );

        assertFalse(flightSet.contains(duplicateFlight));
    }

    @Test
    public void testNonDuplicateFlight() {
        flightSet.add(validFlight);
        Flight nonDuplicateFlight = new Flight(
                2,
                "Suzhou",
                "Wuxi",
                "CH200",
                "United",
                parseTimestamp("02/01/24 15:00:00"),
                parseTimestamp("02/01/24 19:00:00"),
                airplane
        );

        assertFalse(flightSet.contains(nonDuplicateFlight));
    }

    //test for flight ID setting
    @Test
    public void testSetFlightID() {
        validFlight.setFlightID(2);
        assertEquals(2, validFlight.getFlightID());
    }

    //test for flight depart area
    @Test
    public void testSetDepartTo() {
        validFlight.setDepartTo("Beijing");
        assertEquals("Beijing", validFlight.getDepartTo());
    }

    @Test
    public void testSetDepartFrom() {
        validFlight.setDepartFrom("Boston");
        assertEquals("Boston", validFlight.getDepartFrom());
    }

    //Test for setcode of flight
    @Test
    public void testSetCode() {
        validFlight.setCode("SF200");
        assertEquals("SF200", validFlight.getCode());
    }

    //Test for company of flight
    @Test
    public void testSetCompany() {
        validFlight.setCompany("American Airlines");
        assertEquals("American Airlines", validFlight.getCompany());
    }

    //Test for date of flight
    @Test
    public void testSetDateFrom() {
        validFlight.setDateFrom("02/01/24 08:00:00");
        assertEquals(parseTimestamp("02/01/24 08:00:00"), validFlight.getDateFrom());
    }

    @Test
    public void testSetDateTo() {
        validFlight.setDateTo("02/01/24 12:00:00");
        assertEquals(parseTimestamp("02/01/24 12:00:00"), validFlight.getDateTo());
    }

    //test for the airplane information of flight
    @Test
    public void testSetAirplane() {
        Airplane newAirplane = new Airplane(1,"AA",1,2,3);
        validFlight.setAirplane(newAirplane);
        assertEquals(newAirplane, validFlight.getAirplane());
    }
}