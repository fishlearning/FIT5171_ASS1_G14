package org.example;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

public class AirplaneTest {

    // Test for Airplane ID
    @Test
    public void testSetAndGetAirplaneID() {
        Airplane airplane = new Airplane(2, "aa", 50, 220, 2);
        airplane.setAirplaneID(2);
        assertEquals(2, airplane.getAirplaneID());
    }

    // Test for Airplane Model
    @Test
    public void testSetAndGetAirplaneModel() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        airplane.setAirplaneModel("AirbusA380");
        assertEquals("AirbusA380", airplane.getAirplaneModel());
    }


    // Test for invalid Airplane Model
    @Test
    public void testInvalidAirplaneModel() {
        Airplane airplane = new Airplane(1, "ValidModel1", 50, 220, 2);
        assertThrows(IllegalArgumentException.class, () -> airplane.setAirplaneModel("1InvalidModel"));
        assertThrows(IllegalArgumentException.class, () -> airplane.setAirplaneModel("Invalid Model"));
    }

    // Test for Business Sits Number setting
    @Test
    public void testSetAndGetBusinessSitsNumber() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        airplane.setBusinessSitsNumber(50);
        assertEquals(50, airplane.getBusinessSitsNumber());
    }

    // Test for Economy Sits Number setting
    @Test
    public void testSetAndGetEconomySitsNumber() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        airplane.setEconomySitsNumber(220);
        assertEquals(220, airplane.getEconomySitsNumber());
    }

    // Test for Crew Sits Number setting
    @Test
    public void testSetAndGetCrewSitsNumber() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        airplane.setCrewSitsNumber(2);
        assertEquals(2, airplane.getCrewSitsNumber());
    }

    // Test for Business Sits Number range, Boundary Value Testing
    @Test
    public void testBusinessSitsNumberRange() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        assertThrows(IllegalArgumentException.class, () -> airplane.setBusinessSitsNumber(10));
        assertThrows(IllegalArgumentException.class, () -> airplane.setBusinessSitsNumber(61));
    }

    // Test for Economy Sits Number range, Boundary Value Testing
    @Test
    public void testEconomySitsNumberRange() {
        Airplane airplane = new Airplane(1, "AirbusA380", 50, 220, 2);
        assertThrows(IllegalArgumentException.class, () -> airplane.setEconomySitsNumber(60));
        assertThrows(IllegalArgumentException.class, () -> airplane.setEconomySitsNumber(301));
    }

    // Test for Crew Sits Number range, Boundary Value Testing
    @Test
    public void testCrewSitsNumberRange() {
        Airplane airplane = new Airplane(1, "AirbusA380", 60, 220, 2);
        assertThrows(IllegalArgumentException.class, () -> airplane.setCrewSitsNumber(0));
        assertThrows(IllegalArgumentException.class, () -> airplane.setCrewSitsNumber(11));
    }
}