package org.example;

import java.util.ArrayList;
import java.util.List;

public class PersonManager {
    private List<Person> people = new ArrayList<>();

    public void addPerson(Person person) {
        people.add(person);
    }

    public List<Person> getPeople() {
        return people;
    }
}
