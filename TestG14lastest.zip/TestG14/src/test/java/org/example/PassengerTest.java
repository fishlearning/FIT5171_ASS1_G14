package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PassengerTest {

    //test for invalid data setting
    @Test
    public void testPassengerCreationWithValidData() {
        Passenger passenger = new Passenger("Jay", "Chou", 30, "Man", "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        assertNotNull(passenger);
        assertEquals("Jay", passenger.getFirstName());
        assertEquals("Chou", passenger.getSecondName());
        assertEquals(30, passenger.getAge());
        assertEquals("Man", passenger.getGender());
        assertEquals("Jay.Chou@music.com", passenger.getEmail());
        assertEquals("0412 345 678", passenger.getPhoneNumber());
        assertEquals("A12345678", passenger.getPassport());
        assertEquals("1234567890123456", passenger.getCardNumber());
        assertEquals(123, passenger.getSecurityCode());
    }

    //test for invalid email setting
    @Test
    public void testPassengerCreationWithInvalidEmail() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", 30, "Man", "Jay.Chou@com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Invalid email format", exception.getMessage());
    }

    //test for invalid phone number setting
    @Test
    public void testPassengerCreationWithInvalidPhoneNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", 30, "Man", "Jay.Chou@music.com", "0123 456 789", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Invalid phone number format", exception.getMessage());
    }

    //test for invalid passport number setting
    @Test
    public void testPassengerCreationWithInvalidPassport() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", 30, "Man", "Jay.Chou@music.com", "0412 345 678", "A1234567890", "1234567890123456", 123);
        });
        assertEquals("Invalid passport number", exception.getMessage());
    }

    //test for invalid firstname setting
    @Test
    public void testPassengerCreationWithMissingFirstName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger(null, "Chou", 30, "Man", "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception.getMessage());
    }

    //test for invalid second name setting
    @Test
    public void testPassengerCreationWithMissingSecondName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", null, 30, "Man", "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception.getMessage());
    }

    //test for invalid age setting
    @Test
    public void testPassengerCreationWithInvalidAge() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", -1, "Man", "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Age must be greater than 0 and less than 150", exception.getMessage());
    }

    //test for invalid gender setting
    @Test
    public void testPassengerCreationWithInvalidGender() {
        Exception exception1 = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", 30, null, "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception1.getMessage());

        Exception exception2 = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("Jay", "Chou", 30, "aaaa", "Jay.Chou@music.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Invalid gender value", exception2.getMessage());
    }
}