package org.example;

import java.sql.*;
import java.util.*;

public class TicketSystem {
    public TicketCollection ticketCollection;
    public FlightCollection flightCollection;
    public BuyTicket buyTicket;
    private ChooseTicket chooseTicket;
    private Set<Integer> bookedTickets;

    //I merged two classes into one class, named ticket system,this class. This class contains two subclasses
    public TicketSystem() {
        buyTicket = new BuyTicket();
        chooseTicket = new ChooseTicket();
        this.ticketCollection = new TicketCollection();
        this.flightCollection = new FlightCollection();
        this.bookedTickets = new HashSet<>();


    }

    //
    public void chooseAndBuyTicket(String city1, String city2) throws Exception {
        chooseTicket.chooseTicket(city1, city2);
        if (city1 == null || city2 == null || city1 == "Unknown" || city2 == "Unknown" ) {
            throw new IllegalArgumentException("No flights available for the selected cities.");
        }
    }


    public class ChooseTicket {
        private BuyTicket buyTicket;
        private Scanner scanner;

        public ChooseTicket() {
            buyTicket = new BuyTicket();
            scanner = new Scanner(System.in);
        }

        public void chooseTicket(String city1, String city2) throws Exception {
            int counter = 1;
            int idFirst = 0;
            int idSecond = 0;

            List<Flight> flights = FlightCollection.getTwoFlightInfo(city1, city2);

            if (flights != null && !flights.isEmpty()) {
                Flight flight = flights.get(0); // Take the first flight if multiple flights match
                TicketCollection.getAllTickets();

            } else {
                List<Flight> departToList = FlightCollection.getFlightInfo(city2);
                if (departToList != null && !departToList.isEmpty()) {
                    Flight departTo = departToList.get(0); // Take the first flight if multiple flights match
                    String connectCity = departTo.getDepartFrom();
                    List<Flight> connectingFlights = FlightCollection.getTwoFlightInfo(city1, connectCity);
                    if (connectingFlights != null && !connectingFlights.isEmpty()) {
                        Flight flightConnectingTwoCities = connectingFlights.get(0); // Take the first connecting flight if multiple flights match
                        System.out.println("There is a special way to go there. It involves a transfer. Way №" + counter);
                        idFirst = departTo.getFlightID();
                        idSecond = flightConnectingTwoCities.getFlightID();
                    }
                    counter++;
                    buyTicket.buyTicket(idFirst, idSecond);
                }
                if (counter == 1) {
                    System.out.println("There are no possible variants.");

                }
            }
        }
    }

    public class BuyTicket {
        public Scanner in;
        private Passenger passenger;
        private Ticket ticket;
        private Flight flight;
        private Scanner scanner;

        public BuyTicket() {
            passenger = new Passenger();
            ticket = new Ticket();
            scanner = new Scanner(System.in);
        }

        public short showTicket() {
            try {
                System.out.println("You have bought a ticket for flight " + ticket.flight.getDepartFrom() +
                        " - " + ticket.flight.getDepartTo() + "\n\nDetails:");
                System.out.println(ticket.toString());
            } catch (NullPointerException e) {
                System.out.println("No ticket information available.");
            }
            return 0;
        }

        public void buyTicket(int ticketId) throws Exception {
            if (bookedTickets.contains(ticketId)) {
                throw new Exception("Ticket already booked");
            }
            bookedTickets.add(ticketId);
            // Implement your logic to buy a ticket by ticketId
        }

        public void buyTicket(int ticketIdFirst, int ticketIdSecond) throws Exception {
            if (bookedTickets.contains(ticketIdFirst) || bookedTickets.contains(ticketIdSecond)) {
                throw new Exception("Ticket already booked");
            }
            bookedTickets.add(ticketIdFirst);
            bookedTickets.add(ticketIdSecond);
            // Implement your logic to buy a ticket with two flight IDs
        }

        public void handleTicketPurchase(int ticketIdFirst, int ticketIdSecond) throws Exception {
            Ticket validTicketFirst = TicketCollection.getTicketInfo(ticketIdFirst);
            Ticket validTicketSecond = ticketIdSecond > 0 ? TicketCollection.getTicketInfo(ticketIdSecond) : null;

            //the terms of selecting the invalid ticket
            if (validTicketFirst == null || (ticketIdSecond > 0 && validTicketSecond == null)) {
                throw new IllegalArgumentException("One or both tickets do not exist.");
            }

            collectPassengerDetails();

            System.out.println("Do you want to purchase?\n 1-YES 0-NO");
            int purchase = scanner.nextInt();
            if (purchase == 0) {
                return;
            }

            processTicketPurchase(validTicketFirst);
            if (ticketIdSecond > 0) {
                processTicketPurchase(validTicketSecond);
                ticket.setPrice(ticket.getPrice() + validTicketSecond.getPrice());
            }

            System.out.println("Your bill: " + ticket.getPrice() + "\n");
            collectPaymentDetails();
        }


        private void collectPassengerDetails() {
            System.out.println("Enter your First Name: ");
            passenger.setFirstName(scanner.next());

            System.out.println("Enter your Last Name:");
            passenger.setSecondName(scanner.next());

            System.out.println("Enter your age:");
            passenger.setAge(scanner.nextInt());

            System.out.println("Enter your gender: ");
            passenger.setGender(scanner.next());

            System.out.println("Enter your email address:");
            passenger.setEmail(scanner.next());

            System.out.println("Enter your phone number:");
            passenger.setPhoneNumber(scanner.next());

            System.out.println("Enter your passport number:");
            passenger.setPassport(scanner.next());
        }

        private void processTicketPurchase(Ticket validTicket) throws SQLException {
            int flightId = validTicket.getFlight().getFlightID();
            flight = FlightCollection.getFlightInfo(flightId);
            int airplaneId = flight.getAirplane().getAirplaneID();
            Airplane airplane = Airplane.getAirPlaneInfo(airplaneId);

            validTicket.setPassenger(passenger);
            validTicket.setTicketStatus(true);

            if (validTicket.getClassVip()) {
                airplane.setBusinessSitsNumber(airplane.getBusinessSitsNumber() - 1);
            } else {
                airplane.setEconomySitsNumber(airplane.getEconomySitsNumber() - 1);
            }

            ticket = validTicket;
        }

        private void collectPaymentDetails() {
            System.out.println("Enter your card number:");
            passenger.setCardNumber(scanner.next());

            System.out.println("Enter your security code:");
            passenger.setSecurityCode(scanner.nextInt());
        }
    }
}