package org.example;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;

import static org.example.Flight.parseTimestamp;
import static org.junit.jupiter.api.Assertions.*;

public class TicketTest {

    //test for creation of test
    @Test
    public void testTicketCreation() //建票
    {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Flight flight = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane1);
        Passenger passenger = new Passenger("Katze", "Cat", 20, "Man", "Katze.cat@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);

        Ticket ticket = new Ticket(1, 100, flight, false, passenger);

        assertNotNull(ticket);
        assertEquals(1, ticket.getTicket_id());
        assertEquals(100, ticket.getPrice());
        assertEquals(flight, ticket.getFlight());
        assertFalse(ticket.getClassVip());
        assertEquals(passenger, ticket.getPassenger());
        assertFalse(ticket.ticketStatus());
    }

    //test for price setting
    @Test
    public void testSetPrice() {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Flight flight = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane1);
        Passenger passenger = new Passenger("Katze", "Cat", 20, "Man", "Katze.cat@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);


        Ticket ticket = new Ticket(1, 100, flight, false, passenger);
        ticket.setPrice(100);

        assertEquals(112, ticket.getPrice());
        assertThrows(IllegalArgumentException.class, () -> ticket.setPrice(-50));
    }
    //test for ticket status setting
    @Test
    public void setTicketStatus() {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Flight flight = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane1);
        Passenger passenger = new Passenger("Katze", "Cat", 20, "Man", "Katze.cat@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);

        Ticket ticket = new Ticket(1, 100, flight, false, passenger);
        ticket.setTicketStatus(true);
        assertTrue(ticket.ticketStatus());
    }

    //test for the method of different age and different price
    @Test
    public void testSaleByAge() /*折扣与年龄*/{
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Flight flight = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane1);
        Passenger passenger = new Passenger("Katze", "Cat", 20, "Man", "Katze.cat@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);


        Ticket ticket = new Ticket(1, 100, flight, false, passenger);

        // Testing discount for children under 15
        passenger.setAge(10);
        ticket.saleByAge(passenger.getAge());
        assertEquals(50, ticket.getPrice());

        // Testing 100% discount for elder people (age >= 60)
        passenger.setAge(65);
        ticket.saleByAge(passenger.getAge());
        assertEquals(0, ticket.getPrice());
    }

    //test for service tax in price
    @Test
    public void testServiceTax() {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Flight flight = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane1);
        Passenger passenger = new Passenger("Katze", "Cat", 20, "Man", "Katze.cat@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);


        Ticket ticket = new Ticket(1, 100, flight, false, passenger);
        ticket.serviceTax();

        assertEquals(112, ticket.getPrice());
    }

    // Add more tests as needed for other methods and conditions

}