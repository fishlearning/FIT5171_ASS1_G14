package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PassengerTest {

    @Test
    public void testPassengerCreationWithValidData() {
        Passenger passenger = new Passenger("John", "Doe", 30, "Man", "john.doe@example.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        assertNotNull(passenger);
        assertEquals("John", passenger.getFirstName());
        assertEquals("Doe", passenger.getSecondName());
        assertEquals(30, passenger.getAge());
        assertEquals("Man", passenger.getGender());
        assertEquals("john.doe@example.com", passenger.getEmail());
        assertEquals("0412 345 678", passenger.getPhoneNumber());
        assertEquals("A12345678", passenger.getPassport());
        assertEquals("1234567890123456", passenger.getCardNumber());
        assertEquals(123, passenger.getSecurityCode());
    }

    @Test
    public void testPassengerCreationWithInvalidEmail() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", "Doe", 30, "Man", "john.doe@com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Invalid email format", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithInvalidPhoneNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", "Doe", 30, "Man", "john.doe@example.com", "0123 456 789", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Invalid phone number format", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithInvalidPassport() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", "Doe", 30, "Man", "john.doe@example.com", "0412 345 678", "A1234567890", "1234567890123456", 123);
        });
        assertEquals("Invalid passport number", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithMissingFirstName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger(null, "Doe", 30, "Man", "john.doe@example.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithMissingSecondName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", null, 30, "Man", "john.doe@example.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithInvalidAge() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", "Doe", -1, "Man", "john.doe@example.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("Age must be greater than 0 and less than 150", exception.getMessage());
    }

    @Test
    public void testPassengerCreationWithInvalidGender() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Passenger("John", "Doe", 30, null, "john.doe@example.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        });
        assertEquals("All fields must be provided with valid values", exception.getMessage());
    }
}