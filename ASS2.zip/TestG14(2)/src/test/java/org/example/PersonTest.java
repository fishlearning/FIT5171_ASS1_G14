package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class PersonTest {

    @Test
    public void testPersonCreationWithValidData() {
        Person person = new Person("Jay", "Chou", 25, "Man");
        assertNotNull(person);
        assertEquals("Jay", person.getFirstName());
        assertEquals("Chou", person.getSecondName());
        assertEquals(25, person.getAge());
        assertEquals("Man", person.getGender());
    }

    @Test
    public void testPersonCreationWithValidStringAge() {
        Person person = new Person("Jay", "Chou", "25", "Man");
        assertNotNull(person);
        assertEquals(25, person.getAge());
    }

    @Test
    public void testPersonCreationWithNumberWordAge() {
        Person person = new Person("Jay", "Chou", "six", "Man");
        assertNotNull(person);
        assertEquals(6, person.getAge());
    }

    @Test
    public void testPersonCreationWithInvalidStringAge() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("Jay", "Chou", "invalid", "Man");
        });
        assertEquals("Age must be a valid number or number word", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithInvalidGender() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("Jay", "Chou", 25, "InvalidGender");
        });
        assertEquals("Invalid gender value", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithInvalidFirstName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("1Jay", "Chou", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("@Jay", "Chou", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithInvalidSecondName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("Jay", "2Chou", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("Jay", "#Chou", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithMissingFields() {
        assertThrows(IllegalArgumentException.class, () -> new Person(null, "Chou", 25, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("Jay", null, 25, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("Jay", "Chou", -1, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("Jay", "Chou", 25, null));
    }

    @Test
    public void testSetAgeWithString() {
        Person person = new Person("Jay", "Chou", 25, "Man");
        person.setAge("30");
        assertEquals(30, person.getAge());
    }

    @Test
    public void testSetAgeWithNumberWord() {
        Person person = new Person("Jay", "Chou", 6, "Man");
        person.setAge("six");
        assertEquals(6, person.getAge());
    }

    @Test
    public void testAddMultiplePersons() {
        PersonManager manager = new PersonManager();
        manager.addPerson(new Person("Jay", "Chou", 25, "Man"));
        manager.addPerson(new Person("Taylor", "Swift", "six", "Woman"));

        List<Person> people = manager.getPeople();
        assertEquals(2, people.size());
        assertEquals("Jay", people.get(0).getFirstName());
        assertEquals(6, people.get(1).getAge());
    }
}