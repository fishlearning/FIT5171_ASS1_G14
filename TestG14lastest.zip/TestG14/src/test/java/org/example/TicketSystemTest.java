package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.Timestamp;
import java.util.ArrayList;

public class TicketSystemTest {

    private Flight flight;
    private Airplane airplane;
    private Passenger passenger;
    private TicketSystem ticketSystem;

    //some needed information for test
    @BeforeEach
    public void setUp() {
        airplane = new Airplane(1, "Boeing 737", 20, 100, 10);
        flight = new Flight(1, "Sydney", "Melbourne", "SYD-MEL", "Qantas",
                Timestamp.valueOf("2024-07-10 10:00:00"), Timestamp.valueOf("2024-07-10 12:00:00"), airplane);
        passenger = new Passenger("John", "Doe", 30, "Man", "john.doe@example.com", "0400 123 456", "A1234567", "1234567890123456", 123);
        ticketSystem = new TicketSystem();
        FlightCollection.addFlights(new ArrayList<Flight>() {{ add(flight); }});
        Ticket ticket = new Ticket();  // 初始化Ticket对象
    }

    //test for selection by valid city
    @Test
    public void testValidCitySelection() {
        assertDoesNotThrow(() -> ticketSystem.chooseAndBuyTicket("Sydney", "Melbourne"));
    }

    //test for selection by invalid city
    @Test
    public void testInvalidCitySelection() {
        Exception exception = assertThrows(Exception.class, () -> ticketSystem.chooseAndBuyTicket("Unknown", "Melbourne"));
        assertEquals("No flights available for the selected cities.", exception.getMessage());
    }

    //test for booking already booked ticket
    @Test
    public void testAlreadyBookedTicket() throws Exception {
        ticketSystem.buyTicket.buyTicket(1);
        Exception exception = assertThrows(Exception.class, () -> ticketSystem.buyTicket.buyTicket(1));
        assertEquals("Ticket already booked", exception.getMessage());
    }

    //test for valid passenger information
    @Test
    public void testValidPassengerInformation() {
        assertDoesNotThrow(() -> new Passenger("Jane", "Doe", 25, "Woman", "jane.doe@example.com", "0401 234 567", "B1234567", "6543210987654321", 321));
    }

    //test for invalid passenger information
    @Test
    public void testInvalidPassengerInformation() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Passenger("Jane", "Doe", 25, "Woman", "invalid-email", "0401 234 567", "B1234567", "6543210987654321", 321));
        assertEquals("Invalid email format", exception.getMessage());
    }

    //test for valid flight information
    @Test
    public void testValidFlightInformation() {
        assertDoesNotThrow(() -> new Flight(2, "Brisbane", "Sydney", "BNE-SYD", "Virgin",
                Timestamp.valueOf("2024-07-11 08:00:00"), Timestamp.valueOf("2024-07-11 10:00:00"), airplane));
    }

    //test for invalid flight information
    @Test
    public void testInvalidFlightInformation() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Flight(2, "Brisbane", "Sydney1", "BNE-SYD", "Virgin",
                Timestamp.valueOf("2024-07-11 08:00:00"), Timestamp.valueOf("2024-07-11 10:00:00"), airplane));
        assertEquals("Departure locations cannot contain numbers.", exception.getMessage());
    }

    // test for valid ticket information in ticket system
    @Test
    public void testValidTicketInformation() {
        // Example: invalid passenger in ticket

        // Ensure we have valid ticket IDs for testing
        assertDoesNotThrow(() -> new Ticket(1,100,flight,false,passenger));
    }

    //test for invalid ticket information in ticket system
    @Test
    public void testInvalidTicketInformation() {
        // Example: invalid passenger in ticket
        Passenger invalidPassenger = new Passenger();
        invalidPassenger.setFirstName("Jane");
        invalidPassenger.setSecondName("Doe");
        invalidPassenger.setAge(25);
        invalidPassenger.setGender("Woman");
        invalidPassenger.setEmail("jane.doe@example.com");
        invalidPassenger.setPhoneNumber("0401 234 567");
        invalidPassenger.setPassport("B1234567");
        invalidPassenger.setCardNumber("6543210987654321");
        invalidPassenger.setSecurityCode(321);

        // Ensure we have valid ticket IDs for testing
        int validTicketId = 1; // Replace with a valid ticket ID
        Ticket validTicket = new Ticket();
        validTicket.setTicket_id(validTicketId);

        // Validate email format separately
        Exception emailException = assertThrows(IllegalArgumentException.class, () -> {
            invalidPassenger.setEmail("invalid-email");
        });
        assertEquals("Invalid email format", emailException.getMessage());

        // Validate ticket purchase with valid ticket IDs and valid email
        invalidPassenger.setEmail("jane.doe@example.com");
        Exception ticketException = assertThrows(IllegalArgumentException.class, () -> {
            ticketSystem.buyTicket.handleTicketPurchase(validTicket.getTicket_id(), -1);
        });
        assertEquals("One or both tickets do not exist.", ticketException.getMessage());
    }
}


