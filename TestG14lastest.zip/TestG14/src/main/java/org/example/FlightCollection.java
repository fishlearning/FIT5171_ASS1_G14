package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FlightCollection {

    public static ArrayList<Flight> flights = new ArrayList<>();

    public static ArrayList<Flight> getFlights() {
        return flights;
    }

    public static void addFlights(ArrayList<Flight> flights) {
        FlightCollection.flights.addAll(flights);
    }

    public static List<Flight> getFlightInfo(String city) {
        // SELECT flights where depart_to = city
        return flights.stream()
                .filter(f -> f.getDepartTo().equalsIgnoreCase(city))
                .collect(Collectors.toList());
    }
    public static List<Flight> getTwoFlightInfo(String city,String city2) {
        // SELECT flights where depart_to = city
        return flights.stream()
                .filter(f -> f.getDepartTo().equalsIgnoreCase(city))
                .collect(Collectors.toList());
    }
    public static Flight getFlightInfo(int flight_id) {
        // SELECT a flight with a particular flight id
        return flights.stream()
                .filter(f -> f.getFlightID() == flight_id)
                .findFirst()
                .orElse(null);
    }
}