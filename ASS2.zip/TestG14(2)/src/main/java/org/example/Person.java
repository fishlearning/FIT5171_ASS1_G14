package org.example;

import java.util.HashMap;
import java.util.Map;

import java.util.ArrayList;
import java.util.List;


public class Person {
    private String firstName;
    private String secondName;
    private int age;
    private String gender;

    private static final Map<String, Integer> numberWords;

    static {
        numberWords = new HashMap<>();
        numberWords.put("zero", 0);
        numberWords.put("one", 1);
        numberWords.put("two", 2);
        numberWords.put("three", 3);
        numberWords.put("four", 4);
        numberWords.put("five", 5);
        numberWords.put("six", 6);
        numberWords.put("seven", 7);
        numberWords.put("eight", 8);
        numberWords.put("nine", 9);
        numberWords.put("ten", 10);
        // Add more mappings as needed
    }

    public Person() {}

    public Person(String firstName, String secondName, int age, String gender) {
        validate(firstName, secondName, age, gender);
        this.firstName = firstName;
        this.secondName = secondName;
        this.age = age;
        this.gender = gender;
    }

    public Person(String firstName, String secondName, String age, String gender) {
        this(firstName, secondName, parseAge(age), gender);
    }

    private static int parseAge(String ageStr) {
        try {
            return Integer.parseInt(ageStr);
        } catch (NumberFormatException e) {
            Integer age = numberWords.get(ageStr.toLowerCase());
            if (age != null) {
                return age;
            }
            throw new IllegalArgumentException("Age must be a valid number or number word");
        }
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age <= 0 || age >= 150) {
            throw new IllegalArgumentException("Age must be greater than 0 and less than 150");
        }
        this.age = age;
    }

    public void setAge(String age) {
        this.age = parseAge(age);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (!isValidGender(gender)) {
            throw new IllegalArgumentException("Invalid gender value");
        }
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (!isValidName(firstName)) {
            throw new IllegalArgumentException("First name must start with a letter and contain only letters");
        }
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        if (!isValidName(secondName)) {
            throw new IllegalArgumentException("Second name must start with a letter and contain only letters");
        }
        this.secondName = secondName;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", secondName='" + secondName + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                '}';
    }

    private void validate(String firstName, String secondName, int age, String gender) {
        if (firstName == null || firstName.isEmpty() || secondName == null || secondName.isEmpty() ||
                gender == null || gender.isEmpty()) {
            throw new IllegalArgumentException("All fields must be provided with valid values");
        }

        if (!isValidName(firstName) || !isValidName(secondName)) {
            throw new IllegalArgumentException("First name and second name must start with a letter");
        }

        if (age <= 0 || age >= 150) {
            throw new IllegalArgumentException("Age must be greater than 0 and less than 150");
        }

        if (!isValidGender(gender)) {
            throw new IllegalArgumentException("Invalid gender value");
        }
    }

    private boolean isValidName(String name) {
        return name.matches("^[a-zA-Z][a-zA-Z]*$");
    }

    private boolean isValidGender(String gender) {
        return gender.equals("Woman") || gender.equals("Man") ||
                gender.equals("Non-binary | gender diverse") ||
                gender.equals("Prefer not to say") || gender.equals("Other");
    }
}