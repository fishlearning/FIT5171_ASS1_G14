package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.example.Flight.parseTimestamp;
import static org.junit.jupiter.api.Assertions.*;

public class TicketCollectionTest {

    private Ticket ticket1;
    private Ticket ticket2;
    private Ticket ticket3;

    @BeforeEach
    public void setUp() {
        // Initialize some tickets
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Airplane airplane2 = new Airplane(2,"BB",4,5,6);
        Airplane airplane3 = new Airplane(3,"CC",7,8,9);
        // Initialize some flights
        Flight flight1 = new Flight(1, "New York", "Los Angeles", "NY100", "Delta", parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1);
        Flight flight2 = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane2);
        Flight flight3 = new Flight(3, "Suzhou", "Wuxi", "NY102", "BNA", parseTimestamp("03/07/24 10:00:00"), parseTimestamp("03/07/24 11:00:00"), airplane3);

        Passenger passenger1 = new Passenger("John", "Doe", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Passenger passenger2 = new Passenger("JJJ", "Do", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Passenger passenger3 = new Passenger("MMM", "Doee", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);

        ticket1 = new Ticket(1, 100, flight1, false,passenger1);
        ticket2 = new Ticket(2, 150, flight2, false,passenger2);
        ticket3 = new Ticket(3, 200, flight3, false,passenger3);

        // Clear existing tickets before each test
        TicketCollection.getTickets().clear();

        // Add tickets to the collection
        ArrayList<Ticket> initialTickets = new ArrayList<>();
        initialTickets.add(ticket1);
        initialTickets.add(ticket2);
        initialTickets.add(ticket3);
        TicketCollection.addTickets(initialTickets);
    }

    @Test
    public void testAddTickets() {
        // Check if tickets are added correctly
        assertEquals(3, TicketCollection.getTickets().size());
    }

    @Test
    public void testInvalidTickets() {
        // Test adding invalid tickets
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Airplane airplane2 = new Airplane(2,"BB",4,5,6);
        Airplane airplane3 = new Airplane(3,"CC",7,8,9);
        // Initialize some flights
        Flight flight1 = new Flight(1, "New York", "Los Angeles", "NY100", "Delta", parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1);
        Flight flight2 = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane2);
        Flight flight3 = new Flight(3, "Suzhou", "Wuxi", "NY102", "BNA", parseTimestamp("03/07/24 10:00:00"), parseTimestamp("03/07/24 11:00:00"), airplane3);

        Passenger passenger1 = new Passenger("John", "Doe", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Passenger passenger2 = new Passenger("JJJ", "Do", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);
        Passenger passenger3 = new Passenger("MMM", "Doee", 30, "Man", "john.doe@monash.com", "0412 345 678", "A12345678", "1234567890123456", 123);


        assertThrows(IllegalArgumentException.class, () -> new Ticket(4, -50, flight3, false,passenger1));
        assertThrows(IllegalArgumentException.class, () -> new Ticket(0, 100, flight3, false,passenger3));
    }

    @Test
    public void testGetTicketInfoById() {
        // Test getting ticket information by ticket ID
        Ticket result = TicketCollection.getTicketInfo(1);
        assertEquals(ticket1, result);

        result = TicketCollection.getTicketInfo(2);
        assertEquals(ticket2, result);

        result = TicketCollection.getTicketInfo(3);
        assertEquals(ticket3, result);
    }

    @Test
    public void testGetTicketInfoByInvalidId() {
        // Test getting ticket information with an invalid ID
        Ticket result = TicketCollection.getTicketInfo(999);
        assertNull(result);
    }
}