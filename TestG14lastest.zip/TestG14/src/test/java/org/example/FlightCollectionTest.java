package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


import static org.example.Flight.parseTimestamp;
import static org.junit.jupiter.api.Assertions.*;

public class FlightCollectionTest {

    private Flight flight1;
    private Flight flight2;
    private Flight flight3;

    //Set some information for using in test
    @BeforeEach
    public void setUp() {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        Airplane airplane2 = new Airplane(2,"BB",4,5,6);
        Airplane airplane3 = new Airplane(3,"CC",7,8,9);
        // Initialize some flights
        flight1 = new Flight(1, "New York", "Los Angeles", "NY100", "Delta", parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1);
        flight2 = new Flight(2, "Beijing", "Nanjing", "NY101", "CNA", parseTimestamp("02/07/24 10:00:00"), parseTimestamp("02/07/24 11:00:00"), airplane2);
        flight3 = new Flight(3, "Suzhou", "Wuxi", "NY102", "BNA", parseTimestamp("03/07/24 10:00:00"), parseTimestamp("03/07/24 11:00:00"), airplane3);

        // Clear existing flights before each test
        FlightCollection.getFlights().clear();

        // Add flights to the collection
        ArrayList<Flight> initialFlights = new ArrayList<>();
        initialFlights.add(flight1);
        initialFlights.add(flight2);
        initialFlights.add(flight3);
        FlightCollection.addFlights(initialFlights);
    }

    //Test for Flight Information Adding
    @Test
    public void testAddFlights() {
        // Check if flights are added correctly
        assertEquals(3, FlightCollection.getFlights().size());
    }

    //test for Flight city name setting
    @Test
    public void testValidCityNames() {
        // Check if flights have valid city names
        for (Flight flight : FlightCollection.getFlights()) {
            assertNotNull(flight.getDepartFrom());
            assertNotNull(flight.getDepartTo());
            assertTrue(flight.getDepartFrom().matches("[a-zA-Z\\s]+"));
            assertTrue(flight.getDepartTo().matches("[a-zA-Z\\s]+"));
        }
    }

    @Test
    public void testInvalidCityNames() {
        Airplane airplane1 = new Airplane(1, "AA", 1, 2, 3);
        assertThrows(IllegalArgumentException.class, () -> new Flight(1,"555","Nanjing","aaa","eee",parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1));
        assertThrows(IllegalArgumentException.class, () -> new Flight(1,"Beijing","555","aaa","eee",parseTimestamp("01/07/24 10:00:00"), parseTimestamp("01/07/24 11:00:00"), airplane1));
    }

    //Test for get flight information by city name
    @Test
    public void testGetFlightInfoByCity() {
        // Test getting flight information by arrival city
        List<Flight> TargetFlight = new ArrayList<>();
        TargetFlight.add(flight3);
        List<Flight> result = FlightCollection.getFlightInfo("Suzhou");
        assertEquals(1, result.size());
        assertEquals(TargetFlight, result);
    }

    //Test for get flight information by flight ID
    @Test
    public void testGetFlightInfoById() {
        // Test getting flight information by flight ID
        Flight result = FlightCollection.getFlightInfo(1);
        assertEquals(flight1, result);

        result = FlightCollection.getFlightInfo(2);
        assertEquals(flight2, result);

        result = FlightCollection.getFlightInfo(3);
        assertEquals(flight3, result);
    }

    @Test
    public void testGetFlightInfoByInvalidId() {
        // Test getting flight information with an invalid ID
        Flight result = FlightCollection.getFlightInfo(999);
        assertNull(result);
    }
}