package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TicketCollection {
    public static ArrayList<Ticket> tickets = new ArrayList<>();

    public static ArrayList<Ticket> getTickets() {
        return tickets;
    }

    //Accepts an ArrayList of Ticket objects and adds them to the collection.
    //Each ticket is validated using the validateTicket method.
    //If a ticket is invalid, it throws an IllegalArgumentException.
    public static void addTickets(ArrayList<Ticket> tickets_db) {
        for (Ticket ticket : tickets_db) {
            if (validateTicket(ticket)) {
                TicketCollection.tickets.add(ticket);
            } else {
                throw new IllegalArgumentException("Invalid ticket: " + ticket);
            }
        }
    }

    //Searches for a ticket by its ID.
    //Uses Java Streams to filter the tickets and returns the first match.
    //If no match is found, returns null
    public static void getAllTickets() {
        // Display all available tickets from the Ticket collection
        tickets.forEach(System.out::println);
    }

    public static Ticket getTicketInfo(int ticket_id) {
        // SELECT a ticket where ticket id = ticket_id
        return tickets.stream()
                .filter(t -> t.getTicket_id() == ticket_id)
                .findFirst()
                .orElse(null);
    }


    //Validates a Ticket object.
    //Checks if the ticket ID is greater than 0 and the price is greater than 0.
    //Returns true if the ticket is valid, otherwise false
    private static boolean validateTicket(Ticket ticket) {
        return ticket.getTicket_id() > 0 && ticket.getPrice() > 0;
    }

}