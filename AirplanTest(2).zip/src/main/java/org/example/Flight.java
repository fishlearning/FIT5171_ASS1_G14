package org.example;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Flight {
    private int flightID;
    private String departTo;
    private String departFrom;
    private String code;
    private String company;
    private Timestamp dateFrom;
    private Timestamp dateTo;
    Airplane airplane;


    public Flight(int flightID, String departTo, String departFrom, String code, String company, Timestamp dateFrom, Timestamp dateTo, Airplane airplane) {
        if (departTo == null || departFrom == null || code == null || company == null || dateFrom == null || dateTo == null || airplane == null) {
            throw new IllegalArgumentException("All fields are required and cannot be null.");
        }
        if (departTo.matches(".*\\d.*") || departFrom.matches(".*\\d.*")) {
            throw new IllegalArgumentException("Departure locations cannot contain numbers.");
        }
        this.flightID = flightID;
        this.departTo = departTo;
        this.departFrom = departFrom;
        this.code = code;
        this.company = company;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
        this.airplane = airplane;
    }

    public int getFlightID() {
        return flightID;
    }

    public void setFlightID(int flightID) {
        if(flightID == 0){
            throw new IllegalArgumentException("flightID is null");
        }
        this.flightID = flightID;
    }

    public String getDepartTo() {
        return departTo;
    }

    public void setDepartTo(String departTo) {
        if (departTo == null || departTo.trim().isEmpty()) {
            throw new IllegalArgumentException("Destination city name cannot be null or empty");
        }
        this.departTo = departTo;
    }

    public String getDepartFrom() {
        if(departFrom == null){
            throw new IllegalArgumentException("departFrom is null");
        }
        return departFrom;
    }

    public void setDepartFrom(String departFrom) {
        if (departFrom == null || departFrom.trim().isEmpty()) {
            throw new IllegalArgumentException("Destination city name cannot be null or empty");
        }
        this.departFrom = departFrom;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        if (code == null || code.trim().isEmpty()) {
            throw new IllegalArgumentException("Code cannot be null or empty");
        }
        this.code = code;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        if (company == null || company.trim().isEmpty()) {
            throw new IllegalArgumentException("Company cannot be null or empty");
        }
        this.company = company;
    }

    public Timestamp getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        if (dateFrom == null || dateFrom.trim().isEmpty()) {
            throw new IllegalArgumentException("Datefrom cannot be null or empty");
        }
        this.dateFrom = parseTimestamp(dateFrom);
    }

    public Timestamp getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        if (dateTo == null || dateTo.trim().isEmpty()) {
            throw new IllegalArgumentException("Dateto cannot be null or empty");
        }
        this.dateTo = parseTimestamp(dateTo);
    }

    public Airplane getAirplane() {
        return airplane;
    }

    public void setAirplane(Airplane airplane) {
        if(airplane == null){
            throw new IllegalArgumentException("airplane is null");
        }
        this.airplane = airplane;
    }

    public static Timestamp parseTimestamp(String dateStr) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            return new Timestamp(dateFormat.parse(dateStr).getTime());
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format", e);
        }
    }

    @Override
    public String toString() {
        return "Flight{" +
                "airplane=" + airplane +
                ", dateTo=" + getDateTo() +
                ", dateFrom=" + getDateFrom() +
                ", departFrom='" + getDepartFrom() + '\'' +
                ", departTo='" + getDepartTo() + '\'' +
                ", code='" + getCode() + '\'' +
                ", company='" + getCompany() + '\'' +
                '}';
    }
}