package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PersonTest {

    @Test
    public void testPersonCreationWithValidData() {
        Person person = new Person("John", "Doe", 25, "Man");
        assertNotNull(person);
        assertEquals("John", person.getFirstName());
        assertEquals("Doe", person.getSecondName());
        assertEquals(25, person.getAge());
        assertEquals("Man", person.getGender());
    }

    @Test
    public void testPersonCreationWithInvalidGender() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("John", "Doe", 25, "InvalidGender");
        });
        assertEquals("Invalid gender value", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithInvalidFirstName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("1John", "Doe", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("@John", "Doe", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithInvalidSecondName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("John", "2Doe", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Person("John", "#Doe", 25, "Man");
        });
        assertEquals("First name and second name must start with a letter", exception.getMessage());
    }

    @Test
    public void testPersonCreationWithMissingFields() {
        assertThrows(IllegalArgumentException.class, () -> new Person(null, "Doe", 25, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("John", null, 25, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("John", "Doe", -1, "Man"));
        assertThrows(IllegalArgumentException.class, () -> new Person("John", "Doe", 25, null));
    }

}