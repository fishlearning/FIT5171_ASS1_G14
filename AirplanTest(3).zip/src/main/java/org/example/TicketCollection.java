package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TicketCollection {
    public static ArrayList<Ticket> tickets = new ArrayList<>();

    public static ArrayList<Ticket> getTickets() {
        return tickets;
    }

    public static void addTickets(ArrayList<Ticket> tickets_db) {
        for (Ticket ticket : tickets_db) {
            if (validateTicket(ticket)) {
                TicketCollection.tickets.add(ticket);
            } else {
                throw new IllegalArgumentException("Invalid ticket: " + ticket);
            }
        }
    }

    public static void getAllTickets() {
        // Display all available tickets from the Ticket collection
        tickets.forEach(System.out::println);
    }

    public static Ticket getTicketInfo(int ticket_id) {
        // SELECT a ticket where ticket id = ticket_id
        return tickets.stream()
                .filter(t -> t.getTicket_id() == ticket_id)
                .findFirst()
                .orElse(null);
    }

    private static boolean validateTicket(Ticket ticket) {
        return ticket.getTicket_id() > 0 && ticket.getPrice() > 0;
    }

}